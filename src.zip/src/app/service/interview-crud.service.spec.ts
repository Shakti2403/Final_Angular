import { TestBed } from '@angular/core/testing';

import { InterviewCrudService } from './interview-crud.service';

describe('InterviewCrudService', () => {
  let service: InterviewCrudService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InterviewCrudService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
