import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CandidateApplicationFormComponent } from './component/Applicant/candidate-application-form/candidate-application-form.component';
import { EmailComponent } from './component/email/email.component';
import { ApplicantDetailsComponent } from './component/HR/applicant-details/applicant-details.component';
import { HrHomePageComponent } from './component/HR/hr-home-page/hr-home-page.component';
import { SelectedCandidatesComponent } from './component/HR/selected-candidates/selected-candidates.component';
import { FeedbackFormComponent } from './component/Interviewer/feedback-form/feedback-form.component';

import { InterviewerHomePageComponent } from './component/Interviewer/interviewer-home-page/interviewer-home-page.component';
import { CareerPageComponent } from './component/login/career-page/career-page.component';
import { LoginMenuComponent } from './component/login/login-menu/login-menu.component';
import { VerifyLoginComponent } from './component/login/verify-login/verify-login.component';
import { EmpOnBenchComponent } from './component/PM/emp-on-bench/emp-on-bench.component';
import { PmHomePageComponent } from './component/PM/pm-home-page/pm-home-page.component';
import { PmJobRequestComponent } from './component/PM/pm-job-request/pm-job-request.component';
import { AddNewRequestComponent } from './component/TL/add-new-request/add-new-request.component';
import { ExistingRequestComponent } from './component/TL/existing-request/existing-request.component';
import { TlHomePageComponent } from './component/TL/tl-home-page/tl-home-page.component';
import { UpdateRequestComponent } from './component/TL/update-request/update-request.component';

const routes: Routes = [
  {path:"", component: LoginMenuComponent}, 
  {path:"login", component: VerifyLoginComponent},
  {path:"tlhomepage", component: TlHomePageComponent},
  {path:"pmhomepage", component: PmHomePageComponent},
  {path:"hrhomepage", component: HrHomePageComponent},
  {path:"Interviewerhomepage", component: InterviewerHomePageComponent},
  {path:"addnewrequest" ,component:AddNewRequestComponent},
  {path:"existingrequest" ,component:ExistingRequestComponent},
  {path: "updatedetails/:jobId", component: UpdateRequestComponent},
  {path: "pmjobrequest", component: PmJobRequestComponent},
  {path: "employeeonbench/:jobId", component: EmpOnBenchComponent},
  {path: "pulishjob", component: CareerPageComponent},
  {path:"hrjobdescription" , component:HrHomePageComponent},
  {path:"toApplicantPage/:jobId", component: CandidateApplicationFormComponent},
  {path:"applicantdetails",component:ApplicantDetailsComponent},
  {path:"backtohome" , component:LoginMenuComponent},
  {path:"gotofeedbackform", component:FeedbackFormComponent},
  {path:"selectedcandidates", component: SelectedCandidatesComponent},
  {path:"interviewerhomepage",component:InterviewerHomePageComponent},
  {path:"gotoInterviewerhomepage", component:InterviewerHomePageComponent},
  {path:"backtoTLhomepage", component: TlHomePageComponent},
  {path:"sendmail",component:EmailComponent},
  {path:"gotosendmailform" ,component:EmailComponent},
  {path:"selectedcandidatePage", component: SelectedCandidatesComponent},

  //logout

  {path:"tl-logout",component: VerifyLoginComponent},
  {path:"pm-logout",component:VerifyLoginComponent},
  {path:"hr-logout",component:VerifyLoginComponent},
  {path:"interviewer-logout" ,component:VerifyLoginComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
