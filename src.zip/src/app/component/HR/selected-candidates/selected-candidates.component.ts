import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';

@Component({
  selector: 'app-selected-candidates',
  templateUrl: './selected-candidates.component.html',
  styleUrls: ['./selected-candidates.component.css']
})
export class SelectedCandidatesComponent implements OnInit {

  interviewDetails: InterviewDetails[] = [];
  applicantName: string = "";

  applicantId: number = 0;
  applicant: ApplicantDetails[] = [];
  applicantdetails: ApplicantDetails = new ApplicantDetails();
  result: boolean = false;
  interviewdetails: InterviewDetails = new InterviewDetails();

  constructor(private interviewCrudService: InterviewCrudService,
    private activaterouter: ActivatedRoute,private router : Router) { }

  ngOnInit(): void {
   

    this.applicantId = this.activaterouter.snapshot.params['applicantId'];
    console.log(this.applicantId);

    this.applicantName = this.activaterouter.snapshot.params['applicantName'];
    console.log(this.applicantName);

    this.applicantdetails.applicantName = this.applicantName;
   
    
    console.log("in getInterviewDetailsByStatus");

    this.interviewCrudService.getInterviewDetailsByStatus().subscribe(
      data => {
        this.interviewDetails = data;
        console.log(this.interviewDetails);
      }
    );
  }

  selectedtoPassed(interviewdetails: InterviewDetails) {
    console.log("in Selectedpass");
    console.log(interviewdetails);

    this.interviewCrudService.UpdateSelectedToPass(interviewdetails).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
        this.reloadPage();
      }
    );
  }

  reloadPage()
  {
      window.location.reload();
  }


  goToEmailForm()
  {
    this.router.navigate(['gotosendmailform']);
  }

  




  

}
