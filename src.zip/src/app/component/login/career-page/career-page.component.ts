import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JobRequest } from 'src/app/domain/jobrequest';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-career-page',
  templateUrl: './career-page.component.html',
  styleUrls: ['./career-page.component.css']
})
export class CareerPageComponent implements OnInit {

  constructor(private router: Router, private jobServiceCrud : JobRequestCrudService, private activateRoute:ActivatedRoute) { }
 
  jobReq : JobRequest[] = [];
  ngOnInit(): void 
  {
    console.log("get JobRequest By status on page");
    console.log("getJobReqByStatusOnCareerPage");
     this.jobServiceCrud.getJobReqByStatusOnCareerPage().subscribe(
      data =>{
         this.jobReq = data;     
         console.log(this.jobReq);
      }
     );

  }

  ToApplicantPage(jobId : number){
    console.log("in ToApplicantPage");
    console.log(jobId);
    this.router.navigate(['toApplicantPage',jobId]);
  }


  getJobReqByStatusOnCareerPage()
  { console.log("getJobReqByStatusOnCareerPage");
     this.jobServiceCrud.getJobReqByStatusOnCareerPage().subscribe(
      data =>{
         this.jobReq = data;
         console.log(this.jobReq);
         
      }
     );
  }




 

}
