import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviewer-menu-page',
  templateUrl: './interviewer-menu-page.component.html',
  styleUrls: ['./interviewer-menu-page.component.css']
})
export class InterviewerMenuPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
