import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/domain/employeedetails';
import { JobRequest } from 'src/app/domain/jobrequest';
import { Login } from 'src/app/domain/login';
import { ProjectDetails } from 'src/app/domain/projectdetails';
import { EmployeeServiceService } from 'src/app/service/employee-service.service';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-add-new-request',
  templateUrl: './add-new-request.component.html',
  styleUrls: ['./add-new-request.component.css']
})
export class AddNewRequestComponent implements OnInit {
  submitted: boolean = false;
  jobrequest: JobRequest = new JobRequest();
  projectDetails: ProjectDetails = new ProjectDetails();
  result: boolean = false;
  login: Login = new Login();
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  
  ifApproved :string ="Approved";

  skill_3_array: string[] = ['Java', 'Python', 'C++'];


  constructor(private router: Router, private jobRequestCrudServie: JobRequestCrudService, private employeeServieCrudServie: EmployeeServiceService) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    this.employeeServieCrudServie.GetEmployeeByEmployeeId(this.login.userId).subscribe(
      data => {
        this.employeeDetails = data;
        console.log(this.employeeDetails);
        this.projectDetails = this.employeeDetails.projectDetails;
      }
    );

  }

  addNewJobRequest() {
    console.log("in Add new Job Address");
    this.jobrequest.employeeDetails = this.employeeDetails;
    this.jobrequest.projectDetails = this.projectDetails;
    this.jobrequest.status = "Pending";
    this.jobRequestCrudServie.AddNewRequest(this.jobrequest).subscribe(
      data => {
        console.log(data);
        this.result = data;
        this.submitted = true;
      }
    );
  }

  backToAddNewRequest() {
    this.router.navigate(['tlhomepage']);
  }

}
