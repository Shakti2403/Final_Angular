import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JobRequest } from 'src/app/domain/jobrequest';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-update-request',
  templateUrl: './update-request.component.html',
  styleUrls: ['./update-request.component.css']
})
export class UpdateRequestComponent implements OnInit {

submitted:boolean = false;
  result: boolean = false;
  jobId: number = 0;
  count : number = 0;
  jobRequest : JobRequest = new JobRequest();

  constructor(private router : Router,
    private activateroute: ActivatedRoute,
    private jobrequestcrud: JobRequestCrudService) { }

  ngOnInit(): void {
    console.log("in UpdateDetailsComponent");
    this.jobId = this.activateroute.snapshot.params['jobId'];
    console.log(this.jobId);  
  }

  updateDetails(jobRequest : JobRequest){
    console.log("inside Update Details");
    this.jobrequestcrud.updateJobRequest(jobRequest).subscribe(
      data =>{
        this.result = data;
        console.log(this.result);     
        this.submitted = true;
      }
    );
  }

  
  backToExistingRequest()
  {
    this.router.navigate(['backtoTLhomepage']);
  }
}
