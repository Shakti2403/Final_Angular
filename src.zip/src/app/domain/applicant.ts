export class ApplicantDetails
{
    applicantId: number = 0;
    applicantName : string = "";
    mailId : string = "";
    contactNumber : number = 0;
    skill1 : string = "";
    skill2 : string = "";
    skill3 : string = "";
    qualification :string= "";
    experience : number = 0;
    status : string = "";
    jobId: number = 0;
    documentId: number=0;
    
}